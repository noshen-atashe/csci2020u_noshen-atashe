Read Me:
This project was completed in collaboration
Noshen Atashe: 100620403
Saffana Ahammed: 100737688

CSCI 2020U: Assignment 1
Spam Master 3000


Project Information:
The purpose of this project is to detect spam or ham from a given set of data.
It goes through a training and testing phase to detect words that indicate the
state of a file as "spam" or "ham".
UIsolution.png includes an example of the output.


How to run:
Run using IntelliJ. Make sure the appropriate Java and JavaFX
libraries are added to the path before compiling.
You will be prompted to choose a folder to train and test the code.
Please select the "Data" folder in the same repository for this step.
When the program is done going through training phase, the results
will appear in a different window.



Accuracy: 0.9131832797427653
Precision: 0.9685264663805436
