module CSCI2020U.Midterm.Basecode {
    requires javafx.fxml;
    requires javafx.controls;
    opens midterm2021;
}