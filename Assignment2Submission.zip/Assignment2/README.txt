Contributors:
Noshen Atashe and Saffana Ahammed


Usage:
The purpose of this program is to create a file sharing server. The provided code
depends on Noshen's local file path name which can be easily modified to work in
other environments.
To run this program, launch server first and then launch client. Use the contents of
the shared and client file to run this program.