Contributors:
Lombardo michael

Github Repo:
https://github.com/DatLombardo/csci2020u_team61

Usage:
Launch server, then launch client. After one command execution the client
will disconnect as instructed. A simple way to check if the transfer occurred
is just launch another client or check the folder. Be careful changing
the shared and client folder names, the program relies of shared/ and client/
existing in the Assignment2/ folder.
